﻿namespace masada
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernameTextBox = new System.Windows.Forms.TextBox();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.logingButton = new System.Windows.Forms.Button();
            this.adduserButton = new System.Windows.Forms.Button();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.usernameLabel = new System.Windows.Forms.Label();
            this.profileDropdown = new System.Windows.Forms.ComboBox();
            this.profileButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // usernameTextBox
            // 
            this.usernameTextBox.Location = new System.Drawing.Point(237, 45);
            this.usernameTextBox.Name = "usernameTextBox";
            this.usernameTextBox.Size = new System.Drawing.Size(133, 20);
            this.usernameTextBox.TabIndex = 0;
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Location = new System.Drawing.Point(237, 81);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(133, 20);
            this.passwordTextBox.TabIndex = 1;
            // 
            // logingButton
            // 
            this.logingButton.Location = new System.Drawing.Point(184, 136);
            this.logingButton.Name = "logingButton";
            this.logingButton.Size = new System.Drawing.Size(85, 23);
            this.logingButton.TabIndex = 2;
            this.logingButton.Text = "Login";
            this.logingButton.UseVisualStyleBackColor = true;
            this.logingButton.Click += new System.EventHandler(this.logingButton_Click);
            // 
            // adduserButton
            // 
            this.adduserButton.Location = new System.Drawing.Point(285, 136);
            this.adduserButton.Name = "adduserButton";
            this.adduserButton.Size = new System.Drawing.Size(85, 23);
            this.adduserButton.TabIndex = 3;
            this.adduserButton.Text = "Add User";
            this.adduserButton.UseVisualStyleBackColor = true;
            this.adduserButton.Click += new System.EventHandler(this.adduserButton_Click);
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(181, 81);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(53, 13);
            this.passwordLabel.TabIndex = 4;
            this.passwordLabel.Text = "Password";
            // 
            // usernameLabel
            // 
            this.usernameLabel.AutoSize = true;
            this.usernameLabel.Location = new System.Drawing.Point(181, 45);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(55, 13);
            this.usernameLabel.TabIndex = 5;
            this.usernameLabel.Text = "Username";
            // 
            // profileDropdown
            // 
            this.profileDropdown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.profileDropdown.FormattingEnabled = true;
            this.profileDropdown.Location = new System.Drawing.Point(25, 45);
            this.profileDropdown.Name = "profileDropdown";
            this.profileDropdown.Size = new System.Drawing.Size(121, 21);
            this.profileDropdown.TabIndex = 6;
            // 
            // profileButton
            // 
            this.profileButton.Location = new System.Drawing.Point(25, 77);
            this.profileButton.Name = "profileButton";
            this.profileButton.Size = new System.Drawing.Size(75, 23);
            this.profileButton.TabIndex = 7;
            this.profileButton.Text = "Use Profile";
            this.profileButton.UseVisualStyleBackColor = true;
            this.profileButton.Click += new System.EventHandler(this.profileButton_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(543, 242);
            this.Controls.Add(this.profileButton);
            this.Controls.Add(this.profileDropdown);
            this.Controls.Add(this.usernameLabel);
            this.Controls.Add(this.passwordLabel);
            this.Controls.Add(this.adduserButton);
            this.Controls.Add(this.logingButton);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.usernameTextBox);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.Button logingButton;
        private System.Windows.Forms.Button adduserButton;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.Label usernameLabel;
        private System.Windows.Forms.ComboBox profileDropdown;
        private System.Windows.Forms.Button profileButton;


    }
}

