<?php
ini_set("post_max_size", "50000M");
ini_set("memory_limit", "50000M");
//Connect do DB
$db_link = new mysqli('127.0.0.1', '*', '*', '*');
if (mysqli_connect_errno()) {
    // printf("Connect failed: %s\n", mysqli_connect_error());
    exit("Unable to connect to database.");
}
$stmt = $db_link->prepare("SELECT * FROM user_data WHERE user_data.key = ? AND user_data.submitted = 0");
$stmt->bind_param('s', $key);
$key = $_GET["key"];
// execute prepared statment
$stmt->execute();
$result = $stmt->fetch();
$stmt->close();
if ($result != true) {
    header('HTTP/1.0 404 Not Found');
    echo "<h1>404 Not Found</h1>";
    echo "The page that you have requested could not be found.";
    exit();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Keystroke Dynamics Analysis</title>
        <!--{ Meta }-->
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
        <!--{ CSS }-->
        <link href="/static/css/bootstrap.css" rel="stylesheet">
        <link href="/static/css/bootstrap-responsive.min.css" rel="stylesheet">
        <script type="text/javascript">
        var $_GET = <?php echo json_encode($_GET); ?>;
        </script>
    </head>
    <body>
        <div id="keystroke-test" class="container center">
            <div class="row">
                <div class="span6 offset3">
                    <br/>
                    <h1>Keystroke Dynamics Analysis</h1>
                    <hr/>
                    <!-- <p>Hello,</p>
                    <p>There are two simple stages below that you will complete for our keystroke dynamics research. We will not use any data we collect outside our class, it will not be associated with you in our presentation, and we will destroy it at the end of the semester.</p>
                    <p>Thank you for helping us out with our keystroke dynamics research!<br/>– Andrew, Brian, Dylan, Ethan, and Kevin</p>
                    <hr/> -->
                </div>
                <div class="span6 offset3">
                <!--
                    <p>First, type the follwing password-like phrase once into each of the 20 fields. Treat each entry like a password, make sure to type the exact phrase with correct symbols and capitals.</p>
                    <dl class="dl-horizontal">
                        <dt>Password-Like Phrase:</dt>
                        <dd>.tie5Roanl</dd>
                    </dl>

                    <?php
                    $num_fields = 20; // how many times to type password
                    for ($i=1; $i<=$num_fields; $i++) { ?>
                        <input id="pw<?php echo $i; ?>" type="text" class="span3"></input>
                    <?php } ?>
                    <hr/>
                    <p>Second, type the follwing paragraph into the text area below. This is not about speed, just type the whole paragraph as you would type a paragraph in a word processor.</p>
                    <dl>
                        <dt>Paragraph: </dt>
                        <dd>So then, his armour being furbished, his morion turned into a helmet, his hack christened, and he himself confirmed, he came to the conclusion that nothing more was needed now but to look out for a lady to be in love with; for a knight-errant without love was like a tree without leaves or fruit, or a body without a soul. As he said to himself, "If, for my sins, or by my good fortune, I come across some giant hereabouts, a common occurrence with knights-errant, and overthrow him in one onslaught, or cleave him asunder to the waist, or, in short, vanquish and subdue him, will it not be well to have some one I may send him to as a present, that he may come in and fall on his knees before my sweet lady, and in a humble, submissive voice say, 'I am the giant Caraculiambro, lord of the island of Malindrania, vanquished in single combat by the never sufficiently extolled knight Don Quixote of La Mancha, who has commanded me to present myself before your Grace, that your Highness dispose of me at your pleasure'?" Oh, how our good gentleman enjoyed the delivery of this speech, especially when he had thought of some one to call his Lady!</dd>
                    </dl>
                -->
                    <textarea id="text" class="span6" rows="9"></textarea>
                    <button class="btn" onclick="javascript:submitData()">Submit</button>
                </div>
            </div>
            <br/><br/><br/>
        </div>
        <div id="thank-you" style="display:none;" class="container center">
            <div class="row">
                <div id="keystroke-report" class="span6 offset3">
                <!--
                    <br/>
                    <h1>Keystroke Dynamics Analysis</h1>
                    <p>Thank you for participating in our keystroke dynamic research! We will let you know if we come up with any interesting results.</p>
                    <h5>About The Research</h5>
                    <p>Our research looks at two different applications of keystroke biometrics, each of which is centered around verifying user identity. This is done by looking at how a user types and then creating a "keystroke fingerprint" for that user. Every user can have many keystroke fingerprints depending on what the user is typing, what type of keyboard they are using, familiarity with what is being typed, etc. Since many external factors affect keystroke fingerprints the usual goal is to create a keystroke fingerprint for a specific use in a specific environment, it is difficult to use keystroke fingerprints across applications due to these external factors.</p>

                    <h6>Part 1</h6>
                    <p>Our first research component is an attempt to disprove a specific use of keystroke biometrics. Some applications are designed to track a user based on their keystroke fingerprint to verify an identity. If somebody else were to try and use that same application under the original users account, the application would reject the new user because their keystroke fingerprint would not be the same as the user who owns the account. The idea behind this is that an application would be able to guarantee that each account will only allow one user to use the application. This would force multiple users to purchase multiple licenses or create multiple accounts for the given application. We want to show that this is not a fail proof method and therefore that it shouldn't be relied upon.</p>
                    <p>Using all of the data we collect from the paragraph you typed, we are going to create a keystroke fingerprint for you for that specific paragraph. We are then going to partition keystroke fingerprints in to groups that are similar. Using these partitions, we will write some code that captures the keystrokes of the users in a given partition, and then outputs all of those users keystrokes in a controlled way based on a single shared keystroke fingerprint that our code determines. If this works, it will prove that with a small piece of code, we can automate a process to fool applications that attempt to determine user uniqueness based on keystroke biometrics.</p>
                    <p><em>*Our method assumes that the users are in collusion, like a small business that wants to avoid buying a copy of a piece of software for each employee.</em></p>

                    <h6>Part 2</h6>
                    <p>The second component of our research is only going to be completed if we have enough time before the end of the semester. Keystroke biometrics are often used as a second authentication level for users when they type in their password for a website. If this second authentication step is implemented, you could still get your password correct, but if you type it in a way where the keystroke fingerprint doesn't match match you will be rejected from being able to log in. With this extra security, if somebody were to steal or find your password, they still would not be able to log in as you unless they also know your keystroke fingerprint.</p>
                    <p>The tricky part here is designing a method to create keystroke fingerprints and to use those fingerprints to verify an identity. You want a method that correctly rejects adversaries at a high rate(false positive rate), but at the same time does not incorrectly reject the normal user(false negative rate). Since no person types their password the same way every time, you have to be a little loose when determining if two keystroke fingerprints match. There are existing methods that make these comparisons but we want to create a better method. In order to do this our method needs have lower false positive rates and false negative rates. Figuring out a method that is better than existing methods will be difficult since it is more of a statistical exercise that happens to be highly correlated to a user authentication measure.</p>

                    <h5>About Your Data</h5>
                    <p>For both components above we collect fly times and press times. Fly times are the time between one key press and another key press and press times are the time between key press and key release. Each field you typed in has its own data, fly times are listed first as <strong>key&rarr;key:</strong> [<em>times</em>] followed by press times listed as <strong>key:</strong> [<em>times</em>]. All times are in milliseconds.</p>
                -->
                    <p id="show_data"></p>
                    <button class="btn" onclick="javascript:printData()">Show Your Data</button>
                    <button class="btn" onclick="javascript:printJSON()">Print JSON Data</button>
                    <br/><br/><br/><br/><br/><br/>
                </div>
            </div>
            <br/><br/><br/>
        </div>
        <!--{ JavaScript (At the end for quicker page load.) }-->
        <script src="/static/js/jquery.min.js"></script>
        <script src="/static/js/bootstrap.min.js"></script>
        <script src="/static/js/keystroke.js"></script>
    </body>
</html>
