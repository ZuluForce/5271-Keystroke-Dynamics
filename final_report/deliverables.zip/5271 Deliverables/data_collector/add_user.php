<?php
    ini_set("post_max_size", "50000M");
    ini_set("memory_limit", "50000M");

    $user_key = isset($_POST["user_key"]) ? $_POST["user_key"] : "no_key";
    $msg['user_key'] = $user_key;

/*  $to = "brian.t.maurer@me.com";
    $subject = "KeystrokeData";
    $message = "Key: ".$user_key. "Data: ".json_encode($_POST["json_data"]);
    $from = "maure113@umn.edu";
    $headers = "From:" . $from;
    mail($to,$subject,$message,$headers);
*/
    $db_link = new mysqli('127.0.0.1', '*', '*', '*');
    if (mysqli_connect_errno()) {
        // printf("Connect failed: %s\n", mysqli_connect_error());
        exit("Unable to connect to database.");
    }
    // prepare statement
    $stmt = $db_link->prepare("UPDATE `user_data` SET `json_data` = ?, `submitted` = '1' WHERE `key` = ?");
    $stmt->bind_param('ss', $json_data, $key);
    $json_data = isset($_POST["json_data"]) ? stripslashes($_POST["json_data"]) : "";
    $key= $user_key;
    $stmt->execute();

    // execute prepared statment
    $msg['success'] = true;
    echo json_encode($msg);

?>
