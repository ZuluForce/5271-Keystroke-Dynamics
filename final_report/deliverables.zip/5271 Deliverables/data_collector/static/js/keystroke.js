/**
 * Biometric keystroke data collection.
 */
var user_data = {};
var press_time_queue = {};
var last_keydown;
var current_field_id;
var ids_to_keys = {
	/* letters */
	65:"a",	66:"b",	67:"c",	68:"d",	69:"e", 70:"f",	71:"g",	72:"h",	73:"i",	74:"j",
	75:"k",	76:"l",	77:"m",	78:"n",	79:"o",	80:"p",	81:"q",	82:"r",	83:"s",	84:"t",
	85:"u",	86:"v",	87:"w",	88:"x",	89:"y",	90:"z",
	/* other */
	16:"shift", 32:"spc",
	8:"del", 9:"tab", 13:"return", 17:"ctrl", 18:"opt", 20:"cps", 91:"cmd",
	/* numbers */
	48:"0", 49:"1", 50:"2", 51:"3",	52:"4",	53:"5",	54:"6",	55:"7",	56:"8",	57:"9",
	/* arrows */
	37:"left", 38:"right", 39:"up", 40:"down",
	/* symbols */
	186:":", 187:"=", 189:"-", 188:",", 190:".", 191:"/", 192:"`", 219:"[", 220:"\\",
	221:"]", 222:"'",
};


$(document).ready(function() {

	/**
	 * monitor keydown events
	 */
	$(document).keydown(function(e) {
		// add to press time queue
		press_time_queue[e.which] = e.timeStamp;
		// monitor flytimes
		if (last_keydown != undefined  && current_field_id != undefined) {
			if (user_data[current_field_id] == undefined) {
				user_data[current_field_id] = {};
			}
			if (user_data[current_field_id]["fly_times"] == undefined) {
				user_data[current_field_id]["fly_times"] = {};
			}
			if (user_data[current_field_id]["fly_times"][last_keydown.which] == undefined) {
				user_data[current_field_id]["fly_times"][last_keydown.which] = {};
			}
			if (user_data[current_field_id]["fly_times"][last_keydown.which][e.which] == undefined) {
				user_data[current_field_id]["fly_times"][last_keydown.which][e.which] = [];
			}
			user_data[current_field_id]["fly_times"][last_keydown.which][e.which].push(e.timeStamp-last_keydown.timeStamp);
		}
		last_keydown = { "which":e.which, "timeStamp":e.timeStamp };
	});

	/**
	 * monitor keyup events
	 */
	$(document).keyup(function(e) {
		// add press time
		if (press_time_queue[e.which] != undefined && current_field_id != undefined) {
			if (user_data[current_field_id] == undefined) {
				user_data[current_field_id] = {};
			}
			if (user_data[current_field_id]["press_times"] == undefined) {
				user_data[current_field_id]["press_times"] = {};
			}
			if (user_data[current_field_id]["press_times"][e.which] == undefined) {
				user_data[current_field_id]["press_times"][e.which] = [];
			}
			user_data[current_field_id]["press_times"][e.which].push(e.timeStamp - press_time_queue[e.which]);
			delete(press_time_queue[e.which]);
		}
	});

	$("textarea").focus(function() {
		setVars($(this).attr("id"));
	});
	$("input").focus(function() {
		setVars($(this).attr("id"));
	});
	$("textarea").blur(function() {
		setVars();
	});
	$("input").blur(function() {
		setVars();
	});

	setVars = function(field_id) {
		current_field_id = field_id;
		press_time_queue = {};
		last_keydown = undefined;
	};

	submitData = function() {
		$.ajax({
			type: "POST",
			url: "add_user.php",
			data: {
				user_key: $_GET.key,
				json_data: JSON.stringify(user_data)
			},
			dataType: "json"
		}).done(function(msg) {
			console.log( "Data Saved: " + msg );
			$("#keystroke-test").fadeOut(1);
			$("#thank-you").fadeIn();
		});
	};

	printData = function() {
		var text = "";
		for (field in user_data) {
			text += "<h5>"+field+"</h5>";
			text += printField(field);
		}
		$("#keystroke-report > p#show_data").append(text);
	};

	printField = function(field_id) {
		var text = "";
		text += "<dl class=\"dl-horizontal\">";
		for (k1 in user_data[field_id].fly_times) {
			for (k2 in user_data[field_id].fly_times[k1]) {
				text += "<dt>"+ids_to_keys[k1]+"&rarr;"+ids_to_keys[k2]+"</dt> <dd>["+user_data[field_id].fly_times[k1][k2]+"]</dd>";
			}
		}
		text += "</dl>";
		text += "<dl class=\"dl-horizontal\">";
		for (k in user_data[field_id].press_times) {
			text += "<dt>"+ids_to_keys[k]+": </dt> <dd>["+user_data[field_id].press_times[k]+"]</dd>";
		}
		text += "</dl>";
		return text;
	};

	printJSON = function() {
		var text = "";
		text += JSON.stringify(user_data);
		$("#keystroke-report > p#show_data").append(text);
	};

});

















