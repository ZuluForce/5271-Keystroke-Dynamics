<?php
ini_set("post_max_size", "50000M");
ini_set("memory_limit", "50000M");

if (!$_GET['auth'] == "849b4424dd6add8947c22654c83246e867d9d0e287ec5d296b79f717bf836bf8") {
    header('HTTP/1.0 404 Not Found');
    echo "<h1>404 Not Found</h1>";
    echo "The page that you have requested could not be found.";
    exit();
}
// Submit New Participant:
$submitted = false;
if ($_POST["submit"] == "true" && isset($_POST["email"]) && $_POST["email"] != "") {
    // Connect to database
    $db_link = new mysqli('127.0.0.1', 'key_dynamics', '0jvjPn3mNp5OCt5oDKeN3qUORfGpvHjQ', 'keystroke_dynamics');
    if (mysqli_connect_errno()) {
        // printf("Connect failed: %s\n", mysqli_connect_error());
        exit("Unable to connect to database.");
    }
    // prepare statement
    $stmt = $db_link->prepare("INSERT INTO `user_data` (`id`, `key`, `name`, `email`, `json_data`, `submitted`) VALUES (NULL, ?, ?, ?, NULL, '0')");
    $stmt->bind_param('sss', $key, $name, $email);
    // set parameters
    $key = bin2hex(openssl_random_pseudo_bytes(32, $c_ok));
    $name = isset($_POST['name']) ? $_POST["name"] : "";
    $email = isset($_POST['email']) ? $_POST["email"] : "";
    // execute prepared statment
    $stmt->execute();
    $stmt->close();
    $db_link->close();
    $submitted = true;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Keystroke Dynamics Analysis</title>
        <!--{ Meta }-->
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
        <!--{ CSS }-->
        <link href="/static/css/bootstrap.css" rel="stylesheet">
        <link href="/static/css/bootstrap-responsive.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container center">
            <div class="row">
                <div class="span6 offset3">
                    <form class="form-horizontal" action="/whitelist/?auth=<?php echo $_GET["auth"]; ?>" method="POST">
                        <fieldset>
                            <legend>Create a Keystroke Profile</legend>
                            <label>Field 2 is required.</label>
                            <br/>
                            <div class="control-group">
                                <label class="control-label" for="name">Description</label>
                                <div class="controls">
                                    <input id="name" type="text" name="name" placeholder="">
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="email">Field 2</label>
                                <div class="controls">
                                    <input id="email" type="text" name="email" placeholder="">
                                </div>
                            </div>
                            <div class="control-group">
                                <div class="controls">
                                    <button id="submit" type="submit" name="submit" value="true" class="btn">Submit</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                    <hr/>
                    <p>
                        <?php if ($submitted) { ?>
                            The database was successfully updated, here is <!-- the email with  -->a unique URL:
                            <br/>
                            <!-- <br/>
                            Hi,
                            <br/><br/> -->
                            <!-- I am doing a group research project in Computer Security and was wondering if you would be willing to help us out. We are looking at the security of some various keystroke dynamics and we need participants to type some sample text. If you want to help us out just visit the site:  --><a href="<?php echo "/?key=".$key; ?>">Keystroke Dynamics Analysis</a><!-- . It should only take about 15 minutes or less depending on your typing speed.
                            <br/><br/>
                            Thank you!
                            <br/>
                            &mdash; Andrew, Brian, Dylan, Ethan, Kevin -->
                        <?php } ?>
                    </p>
                </div>
            </div>
        </div>
        <!--{ JavaScript (At the end for quicker page load.) }-->
        <script src="/static/js/jquery.min.js"></script>
        <script src="/static/js/bootstrap.min.js"></script>
        <script src="/static/js/keystroke.js"></script>
    </body>
</html>
